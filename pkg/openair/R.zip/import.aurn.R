# TODO: Add comment
# 
# Author: Karl Ropkins
###############################################################################


import.aurn <- function(file, file.type="csv",
		header.at = 5, data.at = 7,
		data.order = c("value", "status", "unit"),
		na.strings = "NA", 
		simplify.names = TRUE, 		
		date.name = "Date", date.break = "-", date.order = "dmy",
		time.name = "time", time.break = ":", time.order = "hm", time.format ="GMT", 
		is.ws = NULL, is.wd = NULL,
		misc.info = c(1, 2, 3, 4),
		site.id = 4,
		bad.24 = TRUE, correct.time = -3600
){
	
#import function for aurn files
	##format over-complex to allow use with multiple similar formats 
	
	sep <- "," #default csv
	if(file.type == "txt") { sep <- "\t" }
	
#import names and tidy up
	file.names <- read.table(file, header = FALSE, sep = sep, skip = (header.at - 1), nrows = 1, colClasses = "character") 
	
	#reset ws, wd names if assigned
	#before make unique and simplify in case it conflicts with changes
	if(is.null(is.ws)==FALSE) { file.names <- gsub(is.ws, "ws", file.names, ignore.case = FALSE) }
	if(is.null(is.wd)==FALSE) { file.names <- gsub(is.wd, "wd", file.names, ignore.case = FALSE) }
	
	file.names <- make.names(file.names, unique =TRUE)
	
	if(simplify.names==TRUE) {
		file.names[grep("carbon.monoxide", file.names, ignore.case = TRUE)] <- "co"
		file.names[grep("pm10", file.names, ignore.case = TRUE)] <- "pm10"
		file.names[grep("pm2.5", file.names, ignore.case = TRUE)] <- "pm2.5"
		file.names[grep("nitric.oxide", file.names, ignore.case = TRUE)] <- "no"
		file.names[grep("nitrogen.oxides", file.names, ignore.case = TRUE)] <- "nox"
		file.names[grep("nitrogen.dioxide", file.names, ignore.case = TRUE)] <- "no2" #always after nox
		file.names[grep("ozone", file.names, ignore.case = TRUE)] <- "o3"
		file.names[grep("sulphur.dioxide", file.names, ignore.case = TRUE)] <- "so2"
		#currently not simplifying any of the organics
	}
	
	for(i in 1:length(data.order)){
		if(data.order[i]=="value") {} else {
			file.names[grep(data.order[i], file.names, ignore.case = TRUE)] <- paste(data.order[i],".", file.names[(grep(data.order[i], file.names, ignore.case = TRUE))-(i-1)], sep="")
		}
	}
	
#import actual data
	file.data <- read.table(file, header = FALSE, sep = sep, skip = (data.at - 1), nrows = -1, na.strings = na.strings)
	names(file.data) <- file.names
	
#date and time timeseries
	
	#date
	date.order <- gsub("d", paste("%d", date.break, sep=""), date.order, ignore.case = TRUE)
	date.order <- gsub("m", paste("%m", date.break, sep = ""), date.order, ignore.case = TRUE)
	date.order <- gsub("y", paste("%Y", date.break, sep = ""), date.order, ignore.case = TRUE)
	date.order <- substr(date.order, 1, (nchar(date.order) - 1))
	
	#time
	time.order <- gsub("h", paste("%H", time.break, sep=""), time.order, ignore.case = TRUE)
	time.order <- gsub("m", paste("%M", time.break, sep = ""), time.order, ignore.case = TRUE)
	time.order <- gsub("s", paste("%S", time.break, sep = ""), time.order, ignore.case = TRUE)
	time.order <- substr(time.order, 1, (nchar(time.order) - 1))
	
	#main routine with bad.24 code
	if(date.name==time.name) {
		a <- as.POSIXct(strptime(as.character(file.data[,date.name]), format = paste(date.order, time.order, sep=" ")), time.format)
		if(bad.24==TRUE) {
			bad.time <- gsub("%H", "24", time.order, ignore.case = TRUE)
			bad.time <- gsub("%M", "00", bad.time, ignore.case = TRUE)
			bad.time <- gsub("%S", "00", bad.time, ignore.case = TRUE)
			a[grep(bad.time, file.data[, date.name], ignore.case = TRUE)] <- as.POSIXlt(strptime(as.character(file.data[,date.name][grep(bad.time, file.data[, date.name], ignore.case = TRUE)]), format = date.order)) + (86400)
		}
	} else {
		a <- as.POSIXct(strptime(paste(as.character(file.data[,date.name]),as.character(file.data[,time.name]),sep=" "), format = paste(date.order, time.order, sep=" ")), time.format)
		if(bad.24==TRUE) {
			bad.time <- gsub("%H", "24", time.order, ignore.case = TRUE)
			bad.time <- gsub("%M", "00", bad.time, ignore.case = TRUE)
			bad.time <- gsub("%S", "00", bad.time, ignore.case = TRUE)
			a[grep(bad.time, file.data[, time.name], ignore.case = TRUE)] <- as.POSIXlt(strptime(as.character(file.data[,date.name][grep(bad.time, file.data[, time.name], ignore.case = TRUE)]), format = date.order)) + (86400)
		}
	} 
	
#strip out old time and date info
	file.data <- file.data[!names(file.data)==date.name]
	file.data <- file.data[!names(file.data)==time.name]
	
#get misc.data
	b <- readLines(file, n = max(c(misc.info, site.id)))
	b <- b[misc.info]
	site.id <- rep(as.factor(gsub(sep, "", b[site.id], ignore.case = TRUE)),nrow(file.data))
	
#package output
	file.data <- cbind(site = site.id, date = a, file.data)
	comment(file.data) <- c(comment(file.data), b)
	if(bad.24==TRUE) {
		comment(file.data) <- c(comment(file.data), "import.aurn operation: bad.24 applied to reset 24:00:00 time entries")
	}
	if(is.null(correct.time)==FALSE) { 
		file.data$date <- file.data$date + correct.time
		comment(file.data) <- c(comment(file.data), paste("import.aurn operation: correct.time (", correct.time, " seconds)", sep=""))
	}
	
#output
	file.data
	
}
