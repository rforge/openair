
smooth.trend <- function(mydata, 
		pollutant = "nox", 
		deseason = TRUE, 
		type = "default",
		simulate = FALSE,
		n = 200, #bootstrap simulations
		autocor = FALSE,
		ylab = pollutant,
		main = "",
		auto.text = TRUE,...)  {        
	
	library(mgcv)
	library(lattice)
	library(zoo)
	
	#extract variables of interest
	if (type == "wd") vars <- c("date", pollutant, "wd")
	if (type == "ws") vars <- c("date", pollutant, "ws")
	if (type == "site") vars <- c("date", pollutant, "site")
	if (type != "wd" & type != "ws" & type != "site") vars <- c("date", pollutant)
	
	# data checks
	mydata <- check.prep(mydata, vars)
	
	mydata <- mydata[, vars]
	
	##cut wd into 8 (0-45 deg etc.)##############################################
	if (type == "default") mydata$wd.cut <- "All data"

	if (type == "hour") mydata$wd.cut <- format(mydata$date, "%H")
	
	if (type == "month") {mydata$wd.cut <- format(mydata$date, "%B")
		period <- "annual"} #does not make sense otherwise
	
	if (type == "weekday") mydata$wd.cut <- format(mydata$date, "%A")
	
	if (type == "wd") {
		
		mydata$wd.cut <- cut(mydata$wd, breaks = seq(22.5, 382.5, 45), 
				labels =c("NE", "E", "SE", "S", "SW", "W", "NW", "N"))
		mydata$wd.cut[is.na(mydata$wd.cut)] <- "N" # for wd < 22.5
		mydata$wd.cut <- ordered(mydata$wd.cut, levels = c("NW", "N", "NE", 
						"W", "E", "SW", "S", "SE"))}
	
	if (type == "ws") mydata$wd.cut <- cut(mydata$ws, breaks = 
						quantile(mydata$ws, probs = 0:8/8, na.rm = TRUE))
	
	if (type == "site") mydata$wd.cut <- mydata$site
	############################################################################
	
	#sometimes data have long trailing NAs, so start and end at first and last data
	min.idx <- min(which(!is.na(mydata[, pollutant])))
	max.idx <- max(which(!is.na(mydata[, pollutant])))	
	mydata <- mydata[min.idx:max.idx, ]
	
	#for overall data and graph plotting
	start.year <- as.numeric(format(mydata$date[1], "%Y"))
	end.year <- as.numeric(format(mydata$date[nrow(mydata)], "%Y"))
	start.month <- as.numeric(format(mydata$date[1], "%m"))
	end.month <- as.numeric(format(mydata$date[nrow(mydata)], "%m"))
	
	process.cond <- function(mydata) {		
		
		# sometimes data have long trailing NAs, so start and end at 
		# first and last data
		min.idx <- min(which(!is.na(mydata[, pollutant])))
		max.idx <- max(which(!is.na(mydata[, pollutant])))	
		mydata <- mydata[min.idx:max.idx, ]
		
		# these subsets may have different dates to overall
		start.year <- as.numeric(format(mydata$date[1], "%Y"))
		end.year <- as.numeric(format(mydata$date[nrow(mydata)], "%Y"))
		start.month <- as.numeric(format(mydata$date[1], "%m"))
		end.month <- as.numeric(format(mydata$date[nrow(mydata)], "%m"))
		
		wd.cut = as.character(unique(na.omit(mydata$wd.cut)))
		
		#use this to make sure all dates are present, even when data are missing
		all.dates <- data.frame(date = seq(
						as.Date(ISOdate(start.year, start.month, 1)), 
						as.Date(ISOdate(end.year, end.month, 1)), 
						by = "months"))
		
		means <- tapply(mydata[, pollutant], format(mydata$date, "%Y-%m"), 
				mean, na.rm = TRUE)
		
		#actual dates in data
		dates <- as.Date(paste(names(means), "-01", sep = ""))
		mydata <- data.frame(dates = dates, means = as.vector(means))
		
		mydata <- merge(mydata, all.dates, by.x = "dates", by.y = "date", 
				all.y = TRUE)
		
		#dates as numeric for GAM fitting
		dates <- seq((start.year + (start.month - 1)/12), 
				(end.year + (end.month - 1)/12), by = 1/12)
		
		mydata$date <- dates
		
		#can't deseason less than 2 years of data
		if (nrow(mydata) < 24) deseason <- FALSE
		
		if (deseason) {
			#interpolate missing data using zoo
			mydata$means <- na.approx(mydata$means)
			
			myts <- ts(mydata$means, start = c(start.year, start.month),
					end = c(end.year, end.month), frequency = 12)
			
			ssd <- stl(myts, s.window = 35, robust = FALSE, s.degree = 0)
			
			deseas <- ssd$time.series[, "trend"] + ssd$time.series[, "remainder"]
			deseas <- as.vector(deseas)
			
			results <- data.frame(date = dates, conc = as.vector(deseas),
					wd.cut = wd.cut)
			
		} else {
			
			results <- data.frame(date = dates, conc = mydata$means,
					wd.cut = wd.cut)
			
		}
		
		if (!simulate) {  #just plot the data   
			mod <- gam(conc ~ s(date), data = results)
			pred <- predict(mod, results, se = TRUE)
			
			results <- cbind(results, pred = pred$fit, 
					lower = pred$fit - 2 * pred$se.fit, 
					upper = pred$fit + 2 * pred$se.fit)
			
		} else {
			
			sam.size = nrow(results)
			boot.pred <- matrix(nrow = sam.size, ncol = n)
			
			print ("Taking bootstrap samples. Please wait...")
			
			#set up bootstrap
			block.length <- 1
			if (autocor) block.length <- round(sam.size^(1/3))
			index <- samp.boot.block(sam.size, n, block.length)
			
			#predict first
			mod <- gam(conc ~ s(date, bs = "tp"), data = results)
			residuals <- residuals(mod) #residuals of the model
			pred.input <- predict(mod, results)
			
			for (i in 1:n) {
				#make new data
				new.data <- data.frame(date = results$date, conc = pred.input + 
								residuals[index[, i]])	
				
				mod <- gam(conc ~ s(date, bs = "tp"), data = new.data)
				pred <- predict(mod, new.data)
				boot.pred[, i] <- pred
				
			}    
			
			#calculate percentiles
			percentiles <- apply(boot.pred, 1, function(x) 
						quantile(x, probs = c(0.025, 0.975)))
			
			results <- cbind(results, pred = rowMeans(boot.pred), 
					lower = percentiles[1, ], 
					upper = percentiles[2, ])
			
		}	
		results	
	}
	
	split.data <- split(mydata, mydata$wd.cut)
	split.data <- lapply(split.data, function(x) process.cond(x))
	split.data <- do.call(rbind, split.data)
	
	#define the levels for plotting
	if (type == "default") {
		
		layout = c(1, 1)
	}
	if (type == "wd") {
		
		layout = c(3, 3)
		
	}
	
	if (type == "hour") {
		levels(split.data$wd.cut) <- paste("hour = ", 0:23)
		
		layout = c(6, 4)
	}
	
	if (type == "weekday") {
		weekdays <- c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
				"Saturday", "Sunday")
		
		split.data$wd.cut <- ordered(split.data$wd.cut, levels = weekdays)
		
		layout = c(3, 3)
	}
	
	if (type == "ws"){
		ws.levels = levels(split.data$wd.cut)
		ws.levels <- gsub("[[]", "", ws.levels)
		ws.levels <- gsub("[]]", "", ws.levels)
		ws.levels <- gsub("[(]", "", ws.levels)
		ws.levels <- gsub("[)]", "", ws.levels)
		ws.levels <- gsub("[,]", " to ", ws.levels)
		levels(split.data$wd.cut) = ws.levels
		
		layout = c(4, 2)
		
	}
	
	if (type == "site") {
		
		N <- length(unique(as.character(mydata$site)))
		if (N == 2) layout <- c(2, 1)
		if (N > 2) layout <- c(ceiling(sqrt(N)), ceiling(sqrt(N)))
	}
	
	strip <- TRUE
	skip <- FALSE
	if (type == "default") 	strip = FALSE #remove strip
	if (type == "wd") skip <-  c(F, F, F, F, T, F, F, F, F)
	
	xyplot(conc ~ date | wd.cut, data = split.data, 
			as.table = TRUE,
			strip = strip,
			layout = layout,
			skip = skip,
			xlab = "year",
			ylab = quick.text(ylab, auto.text),
			main = quick.text(main, auto.text),
			...,
			
			panel = function(x, y, subscripts,...) {
				x1.pol <- seq(start.year, end.year + 1, by = 2)
				x2.pol <- x1.pol + 1
				y1.pol <- min(split.data$conc, na.rm = TRUE) - 100
				y2.pol <- max(split.data$conc, na.rm = TRUE) + 100
				panel.rect(x1.pol, y1.pol, x2.pol, y2.pol, 
						col = "grey95", border = "grey95")
				
				
				x1 <- c(split.data$date[subscripts], rev(split.data$date[subscripts]))
				y1 <- c(split.data$lower[subscripts], rev(split.data$upper[subscripts]))
				lpolygon(x1, y1, col = "lightpink", border = NA)
				llines(split.data$date[subscripts], split.data$pred[subscripts], 
						lwd = 2, col = "red")
				
				panel.xyplot(x, y, type = "b",...)
				
			})
	
	#invisible(results)    
}


