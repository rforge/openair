year.panels <-  function(mydata,
                pollutant = "nox",
                add.smooth = FALSE,
				ylab = pollutant,
				main = "",
				auto.text = TRUE,...) {

    library(lattice)

    #extract variables of interest
    vars <- c("date", pollutant)
    mydata <- mydata[, vars]
    mydata <- mydata[order(mydata$date), ]
    #rename pollutant to keep code consistent
    colnames(mydata)[2] <- "conc"
    
    year <- as.factor(format(mydata$date, "%Y"))
    mydata <- cbind(mydata, year)

    #determine begin/end year (+1) for gridlines and axis
    begin.year <- ISOdate(levels(year)[1], 1, 1, 0, 0)
    end.year <- ISOdate(as.numeric(levels(year)[length(levels(year))]) +1, 1, 1, 0, 0)

    xyplot(conc ~ date | year,
        data = mydata,
        aspect = 0.4,
        as.table = TRUE,
		main = quick.text(main, auto.text),
		ylab = quick.text(ylab, auto.text),
        scales = list(relation = "free",x = list(format = "%b",
        at = seq(begin.year, end.year, by = "2 month"))),...,

        panel = function(x, y,...) {
          #add grid lines every month by finding start/end date
          panel.abline(v = seq(begin.year, end.year, by = "month"), col = "grey85")
          panel.abline(h = 0, col = "grey85")
          panel.grid(h = -1, v = 0)
          panel.xyplot(x, y, type = "l", lwd = 1,...)

          if (add.smooth == TRUE) {
              panel.loess(x, y, lwd = 2, col = "red")
          }
    })
}