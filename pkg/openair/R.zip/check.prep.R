# Check input file and prepare data
# 
# Author: DCC
###############################################################################

check.prep <- function(mydata, Names) {
	
	# first check all variable names are present and stop if they are not
	# tell user which ones are missing
	
	varNames <- names(mydata)
	matching <- Names %in% varNames
	
	if (any(!matching)) {
		# not all variables are present
		stop(cat("Can't find the variable(s)", Names[!matching], "\n"))
	}
	
	# round wd to make processing obvious
	# data already rounded to nearest 10 degress will not be affected
	# data not rounded will be rounded to nearest 10 degrees
	# assumes 10 is average of 5-15 etc
	
	if ("wd" %in% Names) {
		#check for wd <0 or > 360
		if (any(sign(mydata$wd[!is.na(mydata$wd)]) == -1 | mydata$wd[!is.na(mydata$wd)] > 360)) {
			
			warning("Wind direction < 0 or > 360; removing these data") 
			mydata$wd[mydata$wd < 0] <- NA
			mydata$wd[mydata$wd > 360] <- NA
		}
		
		mydata$wd[mydata$wd == 0] <- NA 
		mydata$wd <- 10 * round(mydata$wd / 10)
		mydata$wd[mydata$wd == 0] <- 360   # angles <5 should be in 360 bin
	}
	
	if ("ws" %in% Names) {
		#check for negative wind speeds
		if (any(sign(mydata$ws[!is.na(mydata$ws)]) == -1)) {
			
			warning("Wind speed <0; removing negative data") 
			mydata$ws[mydata$ws < 0] <- NA
		}
	}
		
	#make sure date is ordered in time if present
	if ("date" %in% Names) {
		
		# if date in format dd/mm/yyyy hh:mm (basic check)
		if (length(grep("/", as.character(mydata$date[1]))) > 0) {
			
			mydata$date <- as.POSIXct(strptime(mydata$date, "%d/%m/%Y %H:%M"), "GMT")
		
		}
		
		mydata <- mydata[order(mydata$date), ]
		
	}
	
	#return data frame
	mydata
}



