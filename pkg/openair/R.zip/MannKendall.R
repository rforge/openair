# functions to calculate Mann-Kendall and Sen-Theil slopes
# Uncertainty in slopes are calculated using bootstrap methods
# The block bootstrap used should be regarded as an ongoing development
# see http://www-rcf.usc.edu/~rwilcox/
# 
# Author: DCC with Mann-Kendall and Sen-Theil functions from
# Rand Wilcox
###############################################################################
library(lattice)
library(zoo)
library(boot)

MannKendall <- function(mydata, 
		pollutant = "nox", 
		deseason = FALSE,
		type = "default",
		period = "monthly",
		simulate = FALSE,
		alpha = 0.05,
		dec.place = 2,
		ylab = pollutant,
		main = "",
		auto.text = TRUE,
		autocor = FALSE,...)  {        
	
	# extract variables of interest
	if (type == "wd") vars <- c("date", pollutant, "wd")
	if (type == "ws") vars <- c("date", pollutant, "ws")
	if (type == "site") vars <- c("date", pollutant, "site")
	if (type != "wd" & type != "ws" & type != "site") vars <- c("date", pollutant)
	
	# data checks
	mydata <- check.prep(mydata, vars)
	
	mydata <- mydata[, vars]
	
	# cut wd into 8 (0-45 deg etc.)#############################################
	if (type == "default") mydata$wd.cut <- "All data"
	
	if (type == "hour") mydata$wd.cut <- format(mydata$date, "%H")
	
	if (type == "month") {mydata$wd.cut <- format(mydata$date, "%B")
		period <- "annual"} #does not make sense otherwise
	
	if (type == "weekday") mydata$wd.cut <- format(mydata$date, "%A")
	
	if (type == "wd") {
		
		mydata$wd.cut <- cut(mydata$wd, breaks = seq(22.5, 382.5, 45), 
				labels =c("NE", "E", "SE", "S", "SW", "W", "NW", "N"))
		mydata$wd.cut[is.na(mydata$wd.cut)] <- "N" # for wd < 22.5
		mydata$wd.cut <- ordered(mydata$wd.cut, levels = c("NW", "N", "NE", 
						"W", "E", "SW", "S", "SE"))}
	
	if (type == "ws") mydata$wd.cut <- cut(mydata$ws, breaks = 
						quantile(mydata$ws, probs = 0:8/8, na.rm = TRUE))
	
	if (type == "site") mydata$wd.cut <- mydata$site
	############################################################################
	
# sometimes data have long trailing NAs, so start and end at first and last data
	min.idx <- min(which(!is.na(mydata[, pollutant])))
	max.idx <- max(which(!is.na(mydata[, pollutant])))	
	mydata <- mydata[min.idx:max.idx, ]
	
# for overall data and graph plotting
	start.year <- as.numeric(format(mydata$date[1], "%Y"))
	end.year <- as.numeric(format(mydata$date[nrow(mydata)], "%Y"))
	start.month <- as.numeric(format(mydata$date[1], "%m"))
	end.month <- as.numeric(format(mydata$date[nrow(mydata)], "%m"))
	
	process.cond <- function(mydata) {
		
		# sometimes data have long trailing NAs, so start and end at 
		# first and last data
		min.idx <- min(which(!is.na(mydata[, pollutant])))
		max.idx <- max(which(!is.na(mydata[, pollutant])))	
		mydata <- mydata[min.idx:max.idx, ]
		
		# these subsets may have different dates to overall
		start.year <- as.numeric(format(mydata$date[1], "%Y"))
		end.year <- as.numeric(format(mydata$date[nrow(mydata)], "%Y"))
		start.month <- as.numeric(format(mydata$date[1], "%m"))
		end.month <- as.numeric(format(mydata$date[nrow(mydata)], "%m"))
		
		wd.cut = as.character(unique(na.omit(mydata$wd.cut)))
		
		if (period == "monthly") {
			
			# use this to make sure all dates are present, even when data are missing
			all.dates <- data.frame(date = seq(
							as.Date(ISOdate(start.year, start.month, 1)), 
							as.Date(ISOdate(end.year, end.month, 1)), 
							by = "months"))
			
			means <- tapply(mydata[, pollutant], format(mydata$date, "%Y-%m"), 
					mean, na.rm = TRUE)
			
			# actual dates in data
			dates <- as.Date(paste(names(means), "-01", sep = ""))
			mydata <- data.frame(dates = dates, means = as.vector(means))
			
			mydata <- merge(mydata, all.dates, by.x = "dates", by.y = "date", 
					all.y = TRUE)
			
			#can't deseason less than 2 years of data
			if (nrow(mydata) < 24) deseason <- FALSE
			
			if(deseason) {
				# interpolate missing data using zoo
				mydata$means <- na.approx(mydata$means)
				
				myts <- ts(mydata$means, start = c(start.year, start.month),
						end = c(end.year, end.month), frequency = 12)
				
				ssd <- stl(myts, s.window = 35, robust = FALSE, s.degree = 0)
				
				deseas <- ssd$time.series[, "trend"] + ssd$time.series[, "remainder"]
				
				deseas <- as.vector(deseas)
				
			} else {
				# interpolate missing data using zoo
				#mydata$means <- na.approx(mydata$means)
				deseas = mydata$means
			}
			
			if (type == "month") deseas <- means #do not desason monthly values!
			
			# dates as numeric 
			dates.frac <- seq((start.year + (start.month - 1)/12), 
					(end.year + (end.month - 1)/12), by = 1/12)
			
			results <- data.frame(date = dates.frac, conc = deseas, 
					wd.cut = wd.cut)
			
		} else {
			
			#assume annual
			means <- tapply(mydata[, pollutant], format(mydata$date, "%Y"), 
					mean, na.rm = TRUE)
			dates <- unique(as.numeric(names(means)))
			means <- as.vector(means)
			
			results <- na.omit(data.frame(date = dates, conc = means, 
							wd.cut = wd.cut))
			
		}
		
		results	
	}
	
	split.data <- split(mydata, mydata$wd.cut)
	split.data <- lapply(split.data, function(x) process.cond(x))
	split.data <- do.call(rbind, split.data)
	split.data <- na.omit(split.data)
	
#define the levels for plotting
	if (type == "default") {
		
		layout = c(1, 1)
	}
	if (type == "wd") {
		
		layout = c(3, 3)
	}
	
	if (type == "hour") {
		levels(split.data$wd.cut) <- paste("hour = ", 0:23)
		
		layout = c(6, 4)
	}
	
	if (type == "weekday") {
		weekdays <- c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
				"Saturday", "Sunday")
		
		split.data$wd.cut <- ordered(split.data$wd.cut, levels = weekdays)
		
		layout = c(3, 3)
	}
	
	if (type == "month") {
		
		split.data$wd.cut <- ordered(split.data$wd.cut, levels = month.name) 
		
		layout = c(4, 3)
	}
	
	if (type == "ws"){
		ws.levels = levels(split.data$wd.cut)
		ws.levels <- gsub("[[]", "", ws.levels)
		ws.levels <- gsub("[]]", "", ws.levels)
		ws.levels <- gsub("[(]", "", ws.levels)
		ws.levels <- gsub("[)]", "", ws.levels)
		ws.levels <- gsub("[,]", " to ", ws.levels)
		levels(split.data$wd.cut) = ws.levels
		
		layout = c(4, 2)
		
	}
	
	if (type == "site") {
		
		N <- length(unique(as.character(mydata$site)))
		if (N == 2) layout <- c(2, 1)
		if (N > 2) layout <- c(ceiling(sqrt(N)), ceiling(sqrt(N)))
	}
	
	strip <- TRUE
	skip <- FALSE
	if (type == "default") 	strip = FALSE #remove strip
	if (type == "wd") skip <-  c(FALSE, FALSE, FALSE, FALSE, TRUE, FALSE, FALSE, FALSE, FALSE)
	
	xyplot(conc ~ date | wd.cut, data = split.data,
			ylab = quick.text(ylab, auto.text),
			main = quick.text(main, auto.text),
			xlab = "year",
			as.table = TRUE,
			layout = layout,
			skip = skip,
			strip = strip,...,
			
			panel = function(x, y, subscripts,...){
				x1 <- seq(start.year, end.year + 1, by = 2)
				x2 <- x1 + 1
				y1 <- min(split.data$conc, na.rm = TRUE) - 100
				y2 <- max(split.data$conc, na.rm = TRUE) + 100
				panel.rect(x1, y1, x2, y2, col = "grey95", border = "grey95")
				panel.xyplot(x, y, type = "b",...)
				
				split.date <- split.data[subscripts, "date"]
				split.conc <- split.data[subscripts, "conc"]
				
				# calculate Mann-Kendall, Sen-Theil stats
				if (simulate) {
					
					print ("Calculating Mann-Kendall tau...")
					block.length <- 1
					if(autocor) block.length <- round(length(split.conc)^(1/3))
					
					MKtau <- function(z) tau.boot(z)$cor
					
					boot.res <- tsboot(split.conc, MKtau, R = 1000, 
							l = block.length, sim = "fixed")
					
					# p value; see ?boot for this
					if (sign(boot.res$t0[1]) == 1) {
						p <- 1 - sum(abs(boot.res$t[,1] - 1) > abs(boot.res$t0[1]- 1))/
								(1 + boot.res$R)
					} else {
						p <- 1 - sum(abs(boot.res$t[,1] + 1) > abs(boot.res$t0[1]+ 1))/
								(1 + boot.res$R)
					}
					
				} else {
					
					MKtau <- tau(split.date, split.conc, alpha = alpha)
					p <- MKtau$siglevel # signficance level of trend
					
				}
				coef <- tsp1reg(split.date,	split.conc)$coef
				uncer <- regci(split.date, split.conc, alpha = alpha, 
						autocor = autocor)$regci
				
				print (paste("p = ", p))
				
				if (p >= 0.1) stars <- ""
				if (p < 0.1 & p >= 0.05) stars <- "+"
				if (p < 0.05 & p >= 0.01) stars <- "*"
				if (p < 0.01 & p >= 0.001) stars <- "**"
				if (p < 0.001) stars <- "***"
				
				panel.abline(coef, col = "red")
				panel.abline(a = uncer[1, 1], b = uncer[2, 2], lty = 5, col = "red")
				panel.abline(a = uncer[1, 2], b = uncer[2, 1], lty = 5, col = "red")
				panel.text((start.year + (start.month - 1)/12), max(split.data$conc, na.rm = TRUE), 
						paste(round(coef[2], dec.place), " ", "[", 
								round(uncer[2, 1], dec.place), ", ",
								round(uncer[2, 2], dec.place), "]", 
								" units/year ", stars, sep = ""), cex = 0.7, 
						pos = 4)
			})
	
}




#block bootstrap
#library(boot)
#MKtau <- function(z) tau(dat[,1], z)$cor
#tsboot(dat[,2], MKtau, R = 500, l = 5, sim = "fixed")



