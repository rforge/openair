polar.freq <- function(polar,
		pollutant = "",
		statistic = "frequency",
		ws.int = 1,
		breaks = seq(0, 5000, 500),
		cols = "default",
		trans = TRUE,
		type = "default",
		min.bin = 1,
		border.col = "transparent",
		main = "",
		auto.text = TRUE,...) {
	library(lattice)
	
	
	#extract necessary data
	if (pollutant == "") {
		vars <- c("ws", "wd", "date")
	} else {
		vars <- c("ws", "wd", "date", pollutant)
	}
	
	# data checks
	polar <- check.prep(polar, vars)
	
	polar <- polar[, vars]
	
	# cut as necessary#############################################
	if (type == "default") polar$cond <- "All data"
	
	if (type == "year") polar$cond <- format(polar$date, "%Y")
	
	if (type == "hour") polar$cond <- format(polar$date, "%H")
	
	if (type == "month") polar$cond <- format(polar$date, "%B")
	
	if (type == "weekday") polar$cond <- format(polar$date, "%A")
	
	if (type == "site") polar$cond <- polar$site
	############################################################################
	
	if (!missing(breaks)) trans <- FALSE  #over-ride transform if breaks supplied
	
	#apply square root transform?
	if (trans) coef <- 2 else coef <- 1
	
	#remove all NAs
	polar <- na.omit(polar)
	
	max.ws <- max(ceiling(polar$ws), na.rm = TRUE)
	
	prepare.grid <- function(polar)
	{
		wd <- factor(polar$wd)
		ws <- factor(ws.int * ceiling(polar$ws / ws.int))
		
		if (statistic == "frequency")     #case with only ws and wd
		{
			weights <- tapply(polar$ws, list(wd, ws), function(x) length(na.omit(x)))}
		
		if (statistic == "mean")
		{
			weights <- tapply(polar[, pollutant],
					list(wd, ws), function(x) mean(x, na.rm = TRUE))}
		
		if (statistic == "median")
		{
			weights <- tapply(polar[, pollutant],
					list(wd, ws), function(x) median(x, na.rm = TRUE))}
		
		if (statistic == "max")
		{
			weights <- tapply(polar[, pollutant],
					list(wd, ws), function(x) max(x, na.rm = TRUE))}
		
		if (statistic == "stdev")
		{
			weights <- tapply(polar[, pollutant],
					list(wd, ws), function(x) sd(x, na.rm = TRUE))}
		
		if (statistic == "weighted.mean")
		{
			weights <- tapply(polar[, pollutant], list(wd, ws),
					function(x) (mean(x) * length(x) / nrow(polar)))
			
			#note sum for matrix
			weights <- 100 * weights / sum(sum(weights, na.rm = TRUE))
		}
		
		weights <- as.vector(t(weights))
		
		#frequency - remove points with freq < min.bin
		bin.len <- tapply(polar$ws, list(wd, ws), function(x) length(na.omit(x)))
		binned.len <- as.vector(t(bin.len))
		ids <- which(binned.len < min.bin)
		weights[ids] <- NA
		
		ws.wd <- expand.grid(ws = as.numeric(levels(ws)), wd = as.numeric(levels(wd)))
		weights <- cbind(ws.wd, weights, cond = polar$cond[1]) # add cond variable
		weights
	}
	
	
	poly <- function(dir, speed, colour)
	{
		#offset by 3 so that centre is not compressed
		angle <- seq(dir - 5, dir + 5, length = 10)
		x1 <- (speed + 3) * sin(pi * angle/180)
		y1 <- (speed + 3) * cos(pi * angle/180)
		x2 <- rev((speed + ws.int + 3) * sin(pi * angle/180))
		y2 <- rev((speed + ws.int + 3) * cos(pi * angle/180))
		lpolygon(c(x1, x2), c(y1, y2), col = colour, border = border.col, lwd = 0.5)
	}
	
	results.grid <- split(polar, polar$cond)
	results.grid <- lapply(results.grid, function(x) prepare.grid(x))
	results.grid <- do.call(rbind, results.grid) 
	
	results.grid <- na.omit(results.grid)
	
	
	if (type == "year") {
		results.grid$cond <- as.factor(results.grid$cond)
		levels(results.grid$cond) = unique(format(polar$date, "%Y"))
	}
	
#define the levels for plotting
	if (type == "default") {
		
		levels(results.grid$cond) = paste(format(min(polar$date), "%d % %B %Y"), 
				" to ", format(max(polar$date), "%d % %B %Y"))
		
		layout = c(1, 1)
	}
	
	if (type == "hour") {
		levels(results.grid$cond) <- paste("hour = ", 0:23)
		
		layout = c(6, 4)
	}
	
	if (type == "weekday") {
		weekdays <- c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
				"Saturday", "Sunday")
		
		results.grid$cond <- ordered(results.grid$cond, levels = weekdays)
		
		layout = c(3, 3)
	}
	
	if (type == "month") {
		
		results.grid$cond <- ordered(results.grid$cond, levels = month.name) 
		
		layout = c(4, 3)
	}
	
	if (type == "site") {
		
		N <- length(unique(as.character(mydata$site)))
		if (N == 2) layout <- c(2, 1)
		if (N > 2) layout <- c(ceiling(sqrt(N)), ceiling(sqrt(N)))
	}
	
	results.grid$weights <- results.grid$weights ^ (1 / coef)
	
	nlev = 200
	#handle missing breaks arguments
	if(missing(breaks)) {
		
		breaks = unique(c(0, pretty(results.grid$weights, nlev)))
		br = pretty((results.grid$weights ^ coef), n = 10)  #breaks for scale
	
	} else {
		
		br = breaks
		
	}
	
	nlev2 = length(breaks)
	
	col <- open.colours(cols, (nlev2 - 1))	
	
	results.grid$div <- cut(results.grid$weights, breaks)
	
	#for pollution data
	results.grid$weights[results.grid$weights == "NaN"] <- 0
	results.grid$weights[which(is.na(results.grid$weights))] <- 0
	
	xyplot(ws ~ wd | cond,
			xlim = c(-max.ws - 4.0, max.ws + 4.0),
			ylim = c(-max.ws - 4.0, max.ws + 4.0),
			data = results.grid,
			layout = layout,
			main = quick.text(main, auto.text),
			#strip = strip,
			type = "n",
			xlab = "",
			ylab = "",
			as.table = TRUE,
			aspect = 1,
			scales = list(draw = FALSE),...,
			
			panel = function(x, y, subscripts,...) {
				panel.xyplot(x, y,...)
				
				subdata <- results.grid[subscripts,]
				
				for (i in 1:nrow(subdata)) {
					colour <- col[as.numeric(subdata$div[i])]
					if (subdata$weights[i] == 0) colour <- "transparent"
					poly(subdata$wd[i], subdata$ws[i], colour)
				}
				
				#annotate
				angles <- seq(0, 2 * pi, length = 360)
				sapply(seq(5, 25, 5), function(x) llines((3 + x + ws.int) * 
											sin(angles), (3 + x + ws.int) * 
											cos(angles), col = "grey", lty = 5))
				
				ltext(seq(3 + ws.int, 28 + ws.int, length = 6) * sin(pi/4), 
						seq(3 + ws.int, 28 + ws.int, length = 6) * cos(pi/4),
						seq(0, 25, 5), cex = 0.7, font = 1)
				
			},
			
			legend = list(right = list(fun = draw.colorkey,
							args = list(key = list(col = col[1:length(breaks) - 1], at = breaks,
									labels = list(at = br^(1/coef), labels = br)), draw = FALSE)))
	)
}
# 
# 

