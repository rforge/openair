wind.rose <- function(polar,
		ws.int = 2,
		type = "year",
		cols = "default",
		use.all = FALSE,
		main = "",
		auto.text = TRUE,...) {
	library(lattice)
	library(reshape) # for rbind.fill
	
	
	vars <- c("ws", "wd", "date")
	
	# check data
	polar <- check.prep(polar, vars)
	
	polar <- polar[, vars]
	
	#remove all NAs
	polar <- na.omit(polar)
	
	#set all 0 wd to 360 for plotting
	#met office assumes zero wind angle is calm
	polar$wd[polar$wd == 0] <- NA
	
	#round wd to make it easy to deal with
	polar$wd <- 10 * round(polar$wd/10)
	polar$wd[polar$wd == 0] <- 360   # angles <5 should be in 360 bin
	
	polar$wd <- 30 * round(polar$wd/30)
	polar$wd[polar$wd == 0] <- 360
	
	polar$ws <- ws.int * floor(polar$ws / ws.int) 
	polar$ws[polar$ws == 0] <- ws.int
	polar$ws[polar$ws > 3 * ws.int] <- 3 * ws.int + ws.int
	
	prepare.grid <- function(polar, i) {
		wd <- factor(polar$wd)
		ws <- factor(polar$ws)
		cats <- length(levels(ws)) #number of levels
		labs <- c("ws1", "ws2", "ws3", "ws4")
		levels(ws) <- labs[1:cats]
		weights <- prop.table(table(wd, ws))    #fraction by ws/wd
		weights <- as.data.frame.matrix(weights)
		weights
	}
	
	
	poly <- function(wd, len1, len2, width, colour, x.off = 0, y.off = 0)
	{
		theta <- wd * pi / 180
		offset = 0.02
		len1 <- len1 + offset
		len2 <- len2 + offset
		x1 <- len1 * sin(theta) - width * cos(theta) + x.off
		x2 <- len1 * sin(theta) + width * cos(theta) + x.off
		x3 <- len2 * sin(theta) - width * cos(theta) + x.off
		x4 <- len2 * sin(theta) + width * cos(theta) + x.off
		
		y1 <- len1 * cos(theta) + width * sin(theta) + y.off
		y2 <- len1 * cos(theta) - width * sin(theta) + y.off
		y3 <- len2 * cos(theta) + width * sin(theta) + y.off
		y4 <- len2 * cos(theta) - width * sin(theta) + y.off
		
		lpolygon(c(x1, x2, x4, x3), c(y1, y2, y4, y3), col = colour, border = "grey")
	}
	
	#by year or use all data?
	if (use.all == FALSE) {
		#cut data by year
		if (type == "year") {
			polar$cond <- cut(polar$date, "year", labels = FALSE)
		} else {# must be month
			polar$cond <- as.numeric(format(polar$date, "%m"))
		}
	} else {
		polar$cond <- 1
	}
	
	#prepare input grid
	results.grid <- data.frame("ws1" = NA, "ws2" = NA, "ws3" = NA, "ws4" = NA, wd = NA, cond = NA)
	
	#for (i in min(polar$cond) : max(polar$cond)) {
	for (i in unique(polar$cond)) {
		weights <- prepare.grid(subset(polar, cond == i), i)
		weights <- cbind(weights, wd = as.numeric(rownames(weights)), cond = i)
		results.grid <- rbind.fill(results.grid, weights)
	}
	
	#the cumsum makes it easy to get the sum of the frequencies for each wd
	results.grid <- cbind(t(apply(results.grid[,1:4], 1, cumsum)),
			wd = results.grid$wd, cond = results.grid$cond)
	results.grid <- as.data.frame(results.grid)
	results.grid <- results.grid[2:nrow(results.grid),]
	
	if (use.all == FALSE) {
		#for strip labels
		if (type == "year") {
			results.grid$cond <- as.factor(results.grid$cond)
			levels(results.grid$cond) = unique(format(polar$date, "%Y"))
		} else { #will be month
			results.grid$cond <- as.factor(results.grid$cond)
			levels(results.grid$cond) = month.name
		}
	} else {
		results.grid$cond <- as.factor(results.grid$cond)
		years <- unique(as.numeric(format(polar$date, "%Y")))
		levels(results.grid$cond) = paste(format(min(polar$date), "%d % %B %Y"), 
						" to ", format(max(polar$date), "%d % %B %Y"))
	}
	
	col <- open.colours(cols, 4)	
	
#max frequency to set plot limits
	max.freq = max(results.grid[, 1:4], na.rm = TRUE)
	
	xyplot(ws1 ~ wd | cond,
			xlim = c(-max.freq - 0.02, max.freq + 0.02),
			ylim = c(-max.freq - 0.02, max.freq + 0.06),
			data = results.grid,
			type = "n",
			xlab = "",
			ylab = "",
			main = quick.text(main, auto.text),
			as.table = TRUE,
			aspect = 1,
			scales = list(draw = FALSE),...,
			
			panel = function(x, y, subscripts) {
				panel.xyplot(x, y,...)
				
				#annotate
				angles <- seq(0, 2 * pi, length = 360)
				llines(0.02 * sin(angles), 0.02 * cos(angles), col = "grey85")
				llines(0.12 * sin(angles), 0.12 * cos(angles), col = "grey85")
				llines(0.22 * sin(angles), 0.22 * cos(angles), col = "grey85")
				
				subdata <- results.grid[subscripts,]
				
				for (i in 1:nrow(subdata)) {
					poly(subdata$wd[i], 0, subdata$ws1[i], 0.002, col[1])
					poly(subdata$wd[i], subdata$ws1[i], subdata$ws2[i], 0.004, col[2])
					poly(subdata$wd[i], subdata$ws2[i], subdata$ws3[i], 0.008, col[3])
					poly(subdata$wd[i], subdata$ws3[i], subdata$ws4[i], 0.016, col[4])
				}
				
				ltext(c(0.12, 0.22) * sin(pi/4), c(0.12, 0.22) * cos(pi/4),
						c("10", "20"), cex = 0.7)
				
				lpolygon(c(-max.freq -0.05, max.freq + 0.05, max.freq + 0.05, -max.freq -0.05),
						c(max.freq - 0.01, max.freq - 0.01, max.freq + 0.07, max.freq + 0.07),
						col = "grey95", border = "white")
				
				#for scale
				len <- 2 * max.freq/4
				poly(90, 0, len, 0.002, col[1], -max.freq, max.freq + 0.04)
				poly(90, len, 2 * len, 0.004, col[2], -max.freq, max.freq + 0.04)
				poly(90, 2 * len, 3 * len, 0.008, col[3], -max.freq, max.freq + 0.04)
				poly(90, 3 * len, 4 * len, 0.016, col[4], -max.freq, max.freq + 0.04)
				
				ltext(seq(-max.freq + len/2 + 0.02, 3 * len + len/2 + 0.02, len) , rep(max.freq + 0.01, 4),
						c(paste(0, " to ", ws.int),
								paste(ws.int, " to ", 2 * ws.int),
								paste(2 * ws.int, " to ", 3 * ws.int),
								paste("> ", 3 * ws.int)), cex = 0.7)
				
				ltext(max.freq, -max.freq + 0.02, expression("(m s" ^ -1 * ")"), cex = 0.7, pos = 2 )
				
			}
	)
	
}
# 


