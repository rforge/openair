open.colours <- function(scheme = "default", n = 100) {
library(RColorBrewer)
#heat
heat <- colorRampPalette(c("#FFFFD6", "#FFFF8A", "#FFFB7D", "#FFEF78", "#FFDD76",
        "#FFC473", "#FFA36C", "#F8795F", "#CB444B", "#930030"))

jet <- colorRampPalette(c("#00007F", "blue", "#007FFF", "cyan",
                      "#7FFF7F", "yellow", "#FF7F00", "red", "#7F0000"))

default.col <- colorRampPalette(brewer.pal(11, "Spectral"), interpolate = "spline")

increment <- colorRampPalette(c("#B0FFF1", "#9CFFC7", "#87FF8E", "#A0FF73",
              "#B4FF69", "#CCFF60", "#E7FF56", "#FFF84D", "#FFCB46", "#FF9C40",
              "#FF6939", "#FF3333", "#CC1B62", "#990A7C", "#520066"))


if (length(scheme) == 1) {
    if (scheme == "increment") cols <- increment(n)
    if (scheme == "default") cols <- rev(default.col(n))
    if (scheme == "heat") cols <- heat(n)
    if (scheme == "jet") cols <- jet(n)
}

if (length(scheme) > 1) { #assume user has given own colours
    user.cols  <- colorRampPalette(scheme)
    cols =  user.cols(n)
}


cols
}

