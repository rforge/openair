diurnal.error <- function(mydata, pollutant = "nox",
		local.time = TRUE,
		normalise = FALSE,
		ylab = pollutant,
		name.pol = pollutant,
		main = "",
		auto.text = TRUE,
		...)   {
	
	library(lattice)
	library(Hmisc)
	library(reshape)
	
	#extract variables of interest
	vars <- c("date", pollutant)
	
	# data checks
	mydata <- check.prep(mydata, vars)
	
	mydata <- mydata[, vars]
	
	# ylabs for more than one pollutant
	if (length(pollutant) > 1 & missing(ylab)) ylab <- paste(pollutant[1], ", ", 
				pollutant[2], sep = "")	
	
	# for pollutant names
	if (length(pollutant) == 1) mylab <- quick.text(pollutant, auto.text)
	
	if (length(pollutant) > 1 & missing(name.pol)) mylab <- c(quick.text(pollutant[1], TRUE), 
				quick.text(pollutant[2], TRUE))
	
	if (length(pollutant) > 1 & !missing(name.pol)) mylab <- c(quick.text(name.pol[1], TRUE), 
				quick.text(name.pol[2], TRUE))
	
	if (normalise)
	{
		N <- dim(mydata)[2] #number of columns
		means <- colMeans(mydata[, 2 : N], na.rm = TRUE)
		swept <- sweep(mydata[, 2 : N], 2, means, "/")
		mydata <- cbind(date = mydata[, 1], swept)
		ylab = "normalised level"
	}
	
	mydata <- melt(mydata, id = "date")
	
	#convert to local time
	if (local.time) mydata$date <- as.POSIXct(format(mydata$date, tz = "Europe/London"))
	
	
	#first do diurnal by day of the week ######################################
	calc <- summarize(mydata[, "value"], llist(mydata[, "variable"],
					format(mydata[, "date"], "%w-%H")), smean.cl.normal, na.rm = TRUE)
	
	
	#make the names sensible
	names(calc)[1:3]<- c("pollutant", "day", "conc")
	
	days <- c("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
	
	#for polygon
	x1 <- rep(1:168, 2)
	x2 <- x1
	y1 <- calc$Lower
	y2 <- calc$Upper
	
#polygon that can handle missing data
	poly <- function(start, end, colour) {
		for(i in seq(start, end))
			
			if (!any(is.na(y2[c(i - 1, i)]))){
				lpolygon(c(x1[i - 1], x1[i], x2[i], x2[i - 1]),
						c(y1[i - 1], y1[i], y2[i], y2[i - 1]),
						col = colour, border = 0) }
	}
	
	# deal with missing uncertainty limits - set to mean
	y1[which(is.na(y1))] <- calc$conc[which(is.na(y1))]
	y2[which(is.na(y2))] <- calc$conc[which(is.na(y2))]
	
	cols <- c("#0080ff", "magenta")    #cols for key
	cols <- cols[1:length(pollutant)]
	
	
	plt1 <- xyplot(conc ~ x1, data = calc, type = "l", groups = pollutant,
			ylim = range(y1, y2, na.rm = TRUE),
			xlab = "day of week",
			ylab = quick.text(ylab, TRUE),
			main = quick.text(main, TRUE),
			
			scales = list(x = list(at = seq(13, 157, 24), labels = days) ),#...,
			
			key = list(lines = list(lwd = 2, col = cols),
					space = "bottom",
					lwd = 2,
					text = list(lab = mylab),
					columns = length(pollutant)),
			
			
			panel = function(x, y,...) {
				
				poly(2, length(x1)/2, colour = rgb(0, 0, 1, 0.2))
				poly(length(x1)/2 + 2, length(x1), colour = rgb(1, 0, 0, 0.2))
				
				panel.abline(v = seq(0, 168, 24), col = "grey85")
				panel.grid(h = -1, v = 0)
				panel.xyplot(x, y, lwd = 2,...)
			})
	
	print(plt1, position=c(0, 0.5, 1, 1), more = TRUE)
	
#next do diurnal for all days########### ######################################
	calc <- summarize(mydata[, "value"], llist(mydata[, "variable"],
					format(mydata[, "date"], "%H")), smean.cl.normal, na.rm = TRUE)
	
	#make the names sensible
	names(calc)[1:3]<- c("pollutant", "day", "conc")
	
	#for polygon
	x1 <- rep(0:23, 2)
	x2 <- x1
	y1 <- calc$Lower
	y2 <- calc$Upper
		
	plt2 <- xyplot(conc ~ x1, data = calc, groups = pollutant, type = "l",
			ylim = range(y1, y2, na.rm = TRUE),
			xlab = "hour of day",
			ylab = quick.text(ylab, TRUE),
			main = "",...,
			
			panel = function(x, y,...) {
				
				poly(2, length(x1)/2, colour = rgb(0, 0, 1, 0.2))
				poly(length(x1)/2 + 2, length(x1), colour = rgb(1, 0, 0, 0.2))
				
				panel.grid(h = -1, v = -1)
				panel.xyplot(x, y, lwd = 2,...)
			})
	
	print(plt2, position=c(0, 0, 0.5, 0.6), more = TRUE)
	
#by day of week ################################################################
	calc <- summarize(mydata[, "value"], llist(mydata[, "variable"],
					format(mydata[, "date"], "%w")), smean.cl.normal, na.rm = TRUE)
	
	#make the names sensible
	names(calc)[1:3]<- c("pollutant", "day", "conc")
	
	calc$day <- as.factor(calc$day)
	
	#for decent y-scale
	ymin = 0.99 * min(calc$Lower, na.rm = TRUE)
	ymax = 1.01 * max(calc$Upper, na.rm = TRUE)
	
	plt3 <- xyplot(conc ~ day, groups = pollutant, data = calc,
			par.settings = simpleTheme(pch = 16),
			xlab = "day of week",
			ylim = c(ymin, ymax),
			ylab = quick.text(ylab, TRUE),
			main = "",
			scales = list(x = list(labels = days)),...,
			
			panel = function(x, y,...) {
				#add grid lines every month by finding start/end date
				panel.grid(-1, -1)
				panel.dotplot(x, y, horiz = FALSE, cex = 1,...)
				
				larrows(1:7, calc$Lower[1:7], 1:7, calc$Upper[1:7], code = 3,
						length = 0.1, angle = 90, col = "#0080ff")
				
				larrows(1:7, calc$Lower[8:14], 1:7, calc$Upper[8:14], code = 3,
						length = 0.1, angle = 90, col = "magenta")
			})
	
	print(plt3, position=c(0.5, 0, 1, 0.6))
	
}




