
polar.annulus <- function(polar,
		pollutant = "",
		resolution = "fine",
		local.time = TRUE,
		type = "trend",
		limits = c(0, 100),
		cols = "default",
		width = "normal",
		auto.smooth = FALSE,
		exclude.missing = TRUE,
		k = 15,
		key = TRUE,
		main = "",
		auto.text = TRUE,...) {
	
	#needs access to these packages
	library(mgcv)    #for smoothing surfaces and removing noise
	library(lattice) #basic plotting
	
	#extract variables of interest
	vars <- c("wd", "date", pollutant)
	
	# check data
	polar <- check.prep(polar, vars)
	
	polar <- polar[, vars]
	
	d <- 10      #width of annulus, total = 25
	
	if (width == "normal") upper <- 10
	if (width == "thin") upper <- 15
	if (width == "fat") upper <- 5
	
	#add extra wds - reduces discontinuity at 0/360
	zero.wd <- subset(polar, wd == 360)
	zero.wd$wd <- 0
	polar <- rbind(polar, zero.wd)
	
	# remove NAs
	polar <- na.omit(polar)
	
	#convert to local time
	if (local.time) polar$date <- as.POSIXct(format(polar$date, tz = "Europe/London"))
	
	#for resolution of grid plotting (default = 0.2; fine =0.1)
	if (resolution == "normal") int <- 0.2
	if (resolution == "fine") int <- 0.1
	if (resolution == "ultra.fine") int <- 0.05  #very large files!
	
	
	#different date components, others available
	if (type == "trend")
	{
		month <- as.numeric(format(polar$date, "%m"))
		year <- as.numeric(format(polar$date, "%Y"))
		trend <- year + (month - 1)/12
	}
	
	if (type == "weekday")
	{
		hour <- as.numeric(format(polar$date, "%H"))
		weekday <- as.numeric(format(polar$date, "%w"))
		trend <- weekday + hour / 24
	}
	
	if (type == "season")
	{
		week <- as.numeric(format(polar$date, "%W"))
		trend <- week
	}
	
	if (type == "hour")
	{
		hour <- as.numeric(format(polar$date, "%H"))
		trend <- hour
	}
	trend <- 10 * (trend - min(trend, na.rm = TRUE)) /
			(max(trend, na.rm = TRUE) - min(trend, na.rm = TRUE))
	polar <- cbind(polar, trend)
	
	time.seq <- seq(0, 10, length = 36)
	
	wd <- seq(from = 0, to = 360, 10) #wind directions from 10 to 360
	ws.wd <- expand.grid(time.seq = time.seq, wd = wd)
	
	
	#identify which ws and wd bins the data belong
	#wd.cut <- cut(polar$wd, seq(0, 360, 10))
	wd.cut <- cut(polar$wd, seq(0, 360, length = 38), include.lowest = TRUE)
	
	#divide-up the data for the annulus
	time.cut <- cut(polar$trend, seq(0, 10, length = 37), include.lowest = TRUE)
	
	binned <- tapply(polar[, pollutant], list(wd.cut, time.cut), mean, na.rm = TRUE)
	binned <- as.vector(t(binned))
	
	#data to predict over
	time.seq <- ws.wd$time.seq
	wd <- ws.wd$wd
	
	input.data <- expand.grid(time.seq = seq(0, 10, length = 20/int + 1),
			wd = seq(0, 360, length = 20/int + 1))
	######################Smoothing#################################################
	
	#run GAM to make a smooth surface

	if (auto.smooth == TRUE) {
		
		Mgam <- gam(binned ~ te(time.seq, wd, bs = c("tp", "cc")))
		
	} else { 
		# note use of cyclic smooth for the wind direction component
		Mgam <- gam(binned ~ te(time.seq, wd, k = k, bs = c("tp", "cc")))
		
	} 
	
	pred <- predict.gam(Mgam, input.data)
	pred <- pred
	
	input.data <- cbind(input.data, pred)
	
	if (exclude.missing) {
		
		# exclude predictions too far from data (from mgcv)
		x <- seq(0, 10, length = 20/int + 1)
		y <- seq(0, 360, length = 20/int + 1)
		res <- 20/int + 1
		wsp <- rep(x, res)
		wdp <- rep(y, rep(res, res))
			
		ind <- exclude.too.far(wsp, wdp, polar$trend, polar$wd, dist = 0.03)
		
		input.data$pred[ind] <- NA
		pred <- input.data$pred

	}
	
	#############################################################################
	#transform to new coords
	
	#new grid for plotting
	new.data <- expand.grid(u = seq(-upper - d, upper + d, by = int),
			v = seq(-upper - d, upper + d, by = int),
			z = NA, wd = NA, time.val = NA)
	
	new.data$id <- seq(nrow(new.data))
	
	#calculate wd and time.val in original units (helps with debugging)
	new.data <- within(new.data, time.val <- (u^2 + v^2)^.5  - upper)
	new.data <- within(new.data, wd <- 180 * atan2(u , v) / pi)
	new.data <- within(new.data, wd[wd < 0] <- wd[wd < 0] + 360)  #correct negative wds
	
	#remove ids outside range
	ids <- with(new.data, which((u^2 + v^2)^.5 > d + upper | (u^2 + v^2)^.5 < upper))
	new.data$wd[ids] <- NA
	new.data$time.val[ids] <- NA
	
	#ids where there are data
	ids <- new.data$id[!is.na(new.data$wd)]
	
	#indexes in orginal coordinates
	id.time <- round((2 * d / int) * new.data$time.val[ids] / 10) + 1
	id.wd <- round((2 * d / int) * new.data$wd[ids] / 360) + 1
	
	pred <- matrix(pred, nrow = 20/int + 1, ncol = 20/int +1)
	
	new.data$z[ids] <- sapply(1:length(ids), function(x) pred[id.time[x], id.wd[x]])
	
	#auto-scaling
	nlev = 200  #preferred number of intervals
	#handle missing breaks arguments
	if(missing(limits)) {
		breaks = pretty(new.data$z, n = nlev)
	} else {
		breaks = pretty(limits, n = nlev)
	}
	
	nlev2 = length(breaks)
	
	col <- open.colours(cols, (nlev2 - 1))	
	col.scale = breaks
	
	
	contourplot(z ~ u * v, new.data, axes = FALSE,
			aspect = 1,  
			xlab = "", 
			ylab = "",
			main = quick.text(main, auto.text),
			colorkey = key, at = col.scale, col.regions = col,
			scales = list(draw = FALSE),
			
			len <- upper + d + 3,
			xlim = c(-len, len), ylim =c(-len, len),...,
			
			panel = function(x, y, z,subscripts,...) {
				panel.contourplot(x, y, z, subscripts, at = col.scale,
						lwd = 1, col.regions = col, labels = FALSE)
				
				#add axis line to central polar plot
				llines(c(upper, upper + d), c(0, 0),
						col = "grey20")
				llines(c(0, 0), c(-upper, -upper - d),
						col = "grey20")
				#add axis line to central polar plot
				llines(c(0, 0), c(upper, upper + d),
						col = "grey20")
				llines(c(-upper, -upper - d), c(0, 0),
						col = "grey20")
				
				add.tick <- function(n, start = 0, end = 0) {
					# start is an offset if time series does not begin in January
					
					# left
					lsegments(seq(-upper - start, -upper - d + end, length = n),
							rep(-.5, n),
							seq(-upper - start, -upper - d + end, length = n),
							rep(.5, n), col = "grey20")
					# top
					lsegments(rep(-.5, n),
							seq(upper + start, upper + d - end, length = n),
							rep(.5, n),
							seq(upper + start, upper + d - end, length = n))
					# right
					lsegments(seq(upper + start, upper + d - end, length = n),
							rep(-.5, n),
							seq(upper + start, upper + d - end, length = n),
							rep(.5, n), col = "grey20")
					# bottom
					lsegments(rep(-.5, n),
							seq(-upper - start, -upper - d + end, length = n),
							rep(.5, n),
							seq(-upper - start, -upper - d + end, length = n))
				}
				
				label.axis <- function(x, lab1, lab2, ticks)
				{
					ltext(x, upper, lab1, cex = 0.7, pos = 4)
					ltext(x, upper + d, lab2, cex = 0.7, pos = 4)
					#at bottom
					ltext(-x, -upper, lab1, cex = 0.7, pos = 2)
					ltext(-x, -upper - d, lab2, cex = 0.7, pos = 2)
					add.tick(ticks)
				}
				
				if (type == "trend")
				{
					date.start <- polar$date[1]
					date.end <- polar$date[nrow(polar)]
					label.axis(0, format(date.start, "%b-%Y"), format(date.end, "%b-%Y"), 2)
				
					#add ticks at 1-Jan each year (could be missing dates)
					days <- seq(as.Date(date.start), as.Date(date.end), by = "day")
					
					#find number of Januarys
					num.jans <- which(format(days, "%j") == "001")
					ticks <- length(num.jans)
					start <- 10 * (num.jans[1] - 1) / length(days)
					end <- 10 - 10 * (num.jans[ticks] - 1) / length(days)
					add.tick(ticks, start, end)
				}
				
				if (type == "season")
				{
					label.axis(0, "January", "December", 13)
				}
				
				if (type == "hour")
				{
					label.axis(0, "0", "23", 7)
				}
				
				if (type == "weekday")
				{
					label.axis(0, "Sunday", "Saturday", 8)
				}
				
				# text for directions
				ltext(-upper -d - 1.5, 0, "W")
				ltext(0, -upper - d - 1.5, "S")
				ltext(0, upper + d + 1.5, "N")
				ltext(upper + d + 1.5, 0, "E")
				
			})
	
}

