# TODO: Add comment
# 
# Author: tradcc
# useful utility functions
###############################################################################


rolling <- function(x, pollutant = "o3", new.name = "rolling", 
		hours = 8, data.capture = 75){
	library(zoo)
# function to calculate rolling means with data capture threshold
# new.name = name of new column with rolling data in
# hours is the averaging period
# data capture (%) only data with at least data.capture % will be used in the 
# calculations, else NA is returned
	
	# convert to zoo object so that rollapply can be used
	subdata <- zoo(x[, pollutant], x$date)
	
	check.missing <- function(x) {
		if (length(na.omit(x)) >= round(hours * data.capture / 100)) {
			
			# enough data to calculate statistic
			result <- mean(na.omit(x))
			
		} else {
			# data capture threshold not high enough
			result <- NA		
			
		}
		result
	}
	
	# calculate means
	means <- as.vector(rollapply(subdata, hours, function(x) check.missing(x), 
					align = "left",	na.pad = TRUE))
	
	x <- cbind(x, means)
	
	if (missing(new.name)) new.name <- paste("rolling", hours, pollutant, sep = "")
	names(x)[ncol(x)] <- new.name
	invisible(x)
}



date.pad <- function(mydata) {
	# function to pad-out missing time data
	
	# note, could extend to multiple - maybe option by? e.g. by = "site"
	
	# order by time
	mydata <- mydata[order(mydata$date), ]
	
	date.start <- mydata$date[1]
	date.end <- mydata$date[nrow(mydata)]
	
	all.dates <- data.frame(date = seq(date.start, date.end, by = "hour"))
	
	mydata <- merge(mydata, all.dates, by = "date", all.y = TRUE)
	mydata	
	
}

dailymean <- function(mydata) {
	# function to calculate daily means from hourly means, dealing specifically 
	# with wind direction
	#for wind direction, calculate the components
	mydata$u <- sin(2 * pi * mydata$wd / 360)
	mydata$v <- cos(2 * pi * mydata$wd / 360)
	
	mydata$date <- as.numeric(as.Date(mydata$date))
	
	dailymet <- aggregate(subset(mydata, select = -date),
			mydata["date"], mean, na.rm = TRUE)
	
	#mean wd (theta)
	dailymet <- within(dailymet, {wd <- as.vector(atan2(u, v) * 360 /2 / pi) })
	
	#correct for negative wind directions
	ids <- which(dailymet$wd < 0)  #ids where wd < 0
	dailymet$wd[ids] <- dailymet$wd[ids] + 360
	
	dailymet <- subset(dailymet, select = c(-u, -v))
	class(dailymet$date) <- "Date"  #change back to date
	dailymet
}

useOuterStrips <-function (x, strip = strip.default, strip.left = strip.custom(horizontal = FALSE), 
		strip.lines = 1, strip.left.lines = strip.lines) 
# direct copy from latticeExtra
{
	dimx <- dim(x)
	stopifnot(inherits(x, "trellis"))
	stopifnot(length(dimx) == 2)
	opar <- if (is.null(x$par.settings)) 
				list()
			else x$par.settings
	par.settings <- modifyList(opar, list(layout.heights = if (x$as.table) list(strip = c(strip.lines, 
												rep(0, dimx[2] - 1))) else list(strip = c(rep(0, dimx[2] - 
																1), 1)), layout.widths = list(strip.left = c(strip.left.lines, 
									rep(0, dimx[1] - 1)))))
	if (is.character(strip)) 
		strip <- get(strip)
	if (is.logical(strip) && strip) 
		strip <- strip.default
	new.strip <- if (is.function(strip)) {
				function(which.given, which.panel, var.name, ...) {
					if (which.given == 1) 
						strip(which.given = 1, which.panel = which.panel[1], 
								var.name = var.name[1], ...)
				}
			}
			else strip
	if (is.character(strip.left)) 
		strip.left <- get(strip.left)
	if (is.logical(strip.left) && strip.left) 
		strip.left <- strip.custom(horizontal = FALSE)
	new.strip.left <- if (is.function(strip.left)) {
				function(which.given, which.panel, var.name, ...) {
					if (which.given == 2) 
						strip.left(which.given = 1, which.panel = which.panel[2], 
								var.name = var.name[2], ...)
				}
			}
			else strip.left
	update(x, par.settings = par.settings, strip = new.strip, 
			strip.left = new.strip.left, par.strip.text = list(lines = 0.5), 
			layout = dimx)
}
